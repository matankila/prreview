# Changelog

## [0.14.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.13.0...module@v0.14.0) (2026-01-22)


### Features

* add ServiceMonitor support and extraObjectsDict ([#80](https://github.com/Codium-ai/helm-charts/issues/80)) ([a23a67f](https://github.com/Codium-ai/helm-charts/commit/a23a67f2e432dedf7519b3ad343366fb4af09450))
* **scaledJob:** add template for keda scaledJob resources ([c967a17](https://github.com/Codium-ai/helm-charts/commit/c967a171116647c52ab0ac55e8154eeed50f4068))
* **scaledJob:** add template for keda scaledJob resources ([#76](https://github.com/Codium-ai/helm-charts/issues/76)) ([1d8dd4d](https://github.com/Codium-ai/helm-charts/commit/1d8dd4da97adcab5d92f41f51b92a2fd337adca2))

## [0.13.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.12.4...module@v0.13.0) (2025-11-19)


### Features

* Adding secret ref as env ([#74](https://github.com/Codium-ai/helm-charts/issues/74)) ([4f3d948](https://github.com/Codium-ai/helm-charts/commit/4f3d948c715f29addd394a2ae046cda6fd11edca))

## [0.12.4](https://github.com/Codium-ai/helm-charts/compare/module@v0.12.3...module@v0.12.4) (2025-11-12)


### Bug Fixes

* fix container comands in tempalde ([#72](https://github.com/Codium-ai/helm-charts/issues/72)) ([ae0754e](https://github.com/Codium-ai/helm-charts/commit/ae0754e8dfab42cebdce5dc57191768626eabeae))

## [0.12.3](https://github.com/Codium-ai/helm-charts/compare/module@v0.12.2...module@v0.12.3) (2025-11-12)


### Bug Fixes

* fix sidecar args and command default behaviour ([#70](https://github.com/Codium-ai/helm-charts/issues/70)) ([e63cfcd](https://github.com/Codium-ai/helm-charts/commit/e63cfcdda4aefba8f1cb28f4b9cb6a6c65df6119))

## [0.12.2](https://github.com/Codium-ai/helm-charts/compare/module@v0.12.1...module@v0.12.2) (2025-11-11)


### Bug Fixes

* handle nil podLabels in job template ([08fd83f](https://github.com/Codium-ai/helm-charts/commit/08fd83f7587a231eb9df5bcb81fc0c359777aac9))
* handle nil podLabels in job template ([#67](https://github.com/Codium-ai/helm-charts/issues/67)) ([f2c131b](https://github.com/Codium-ai/helm-charts/commit/f2c131b6168ef66d9a56524fad76f3588119f032))

## [0.12.1](https://github.com/Codium-ai/helm-charts/compare/module@v0.12.0...module@v0.12.1) (2025-11-11)


### Bug Fixes

* fix job template ([#65](https://github.com/Codium-ai/helm-charts/issues/65)) ([b6fe6f6](https://github.com/Codium-ai/helm-charts/commit/b6fe6f63466ac4f539138dc072c8ebc232acb775))

## [0.12.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.11.1...module@v0.12.0) (2025-11-11)


### Features

* Adding pod labels for jobs ([#63](https://github.com/Codium-ai/helm-charts/issues/63)) ([efbfa5d](https://github.com/Codium-ai/helm-charts/commit/efbfa5d75677fdaaeb288e0f86f189143bade055))

## [0.11.1](https://github.com/Codium-ai/helm-charts/compare/module@v0.11.0...module@v0.11.1) (2025-10-30)


### Bug Fixes

* allow annotations templating in service account ([#61](https://github.com/Codium-ai/helm-charts/issues/61)) ([f1dd938](https://github.com/Codium-ai/helm-charts/commit/f1dd9385148fbc9fec1cbb73f25a26961806bc33))

## [0.11.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.10.1...module@v0.11.0) (2025-10-24)


### Features

* rbac resources support ([#59](https://github.com/Codium-ai/helm-charts/issues/59)) ([adc8dbb](https://github.com/Codium-ai/helm-charts/commit/adc8dbb28a21841aece20bdd498ca4d008b06053))

## [0.10.1](https://github.com/Codium-ai/helm-charts/compare/module@v0.10.0...module@v0.10.1) (2025-10-24)


### Bug Fixes

* Add templating support for KEDA scaledObject spec ([#57](https://github.com/Codium-ai/helm-charts/issues/57)) ([9e849ba](https://github.com/Codium-ai/helm-charts/commit/9e849bac8e42c2d1b751319499ea95aba775589f))

## [0.10.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.9.0...module@v0.10.0) (2025-10-17)


### Features

* PV and PVC support ([#55](https://github.com/Codium-ai/helm-charts/issues/55)) ([dd5342c](https://github.com/Codium-ai/helm-charts/commit/dd5342cf146efa2a881977c019f18ede2129cd48))

## [0.9.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.8.1...module@v0.9.0) (2025-10-03)


### Features

* adding Scaled objects ([#52](https://github.com/Codium-ai/helm-charts/issues/52)) ([f5856d7](https://github.com/Codium-ai/helm-charts/commit/f5856d7cca042c9777de1c850e2599285a386ea7))

## [0.8.1](https://github.com/Codium-ai/helm-charts/compare/module@v0.8.0...module@v0.8.1) (2025-08-28)


### Bug Fixes

* configmap: allow to override app name with underscore syntax too ([#50](https://github.com/Codium-ai/helm-charts/issues/50)) ([32dbcdc](https://github.com/Codium-ai/helm-charts/commit/32dbcdce5bc093d32c5fbca9b8320e0d531c0e96))

## [0.8.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.7.0...module@v0.8.0) (2025-08-11)


### Features

* add support for externalSecrets.secretsDict - for multiple values fil… ([#48](https://github.com/Codium-ai/helm-charts/issues/48)) ([a17569b](https://github.com/Codium-ai/helm-charts/commit/a17569b1abd8df7d68265c443b6d9e8833234c5b))

## [0.7.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.6.0...module@v0.7.0) (2025-08-08)


### Features

* external-secret template: add support for secret annotations ([#46](https://github.com/Codium-ai/helm-charts/issues/46)) ([80c36fd](https://github.com/Codium-ai/helm-charts/commit/80c36fdd1fb4a8e6162b8a9f399147afa755ff78))

## [0.6.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.5.0...module@v0.6.0) (2025-07-17)


### Features

* external-secret: flag to use stable v1 API and allow overriding secre… ([#44](https://github.com/Codium-ai/helm-charts/issues/44)) ([c4a0560](https://github.com/Codium-ai/helm-charts/commit/c4a0560dcc32dd67a35ba3e84c1295340cf79dd7))

## [0.5.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.4.4...module@v0.5.0) (2025-06-11)


### Features

* add support for useShortName for configMaps in volumes ([#35](https://github.com/Codium-ai/helm-charts/issues/35)) ([8bf99e6](https://github.com/Codium-ai/helm-charts/commit/8bf99e672626240844a1502c32dd1395f02d83f9))

## [0.4.4](https://github.com/Codium-ai/helm-charts/compare/module@v0.4.3...module@v0.4.4) (2025-05-28)


### Bug Fixes

* Add support for annotations on imagePullSecret by vendor ([87efd33](https://github.com/Codium-ai/helm-charts/commit/87efd337b228e07df455a9d5e524d5a3d5df85cd))

## [0.3.5](https://github.com/Codium-ai/helm-charts/compare/module@v0.3.4...module@v0.3.5) (2025-04-14)


### Bug Fixes

* simulate hotfix ([eb4b88a](https://github.com/Codium-ai/helm-charts/commit/eb4b88aa5367791beb0205468de8041cfd6d3e0d))

## [0.4.3](https://github.com/Codium-ai/helm-charts/compare/module@v0.4.2...module@v0.4.3) (2025-04-03)


### Bug Fixes

* job indentation for imagePullSecrets ([#23](https://github.com/Codium-ai/helm-charts/issues/23)) ([9aba5b1](https://github.com/Codium-ai/helm-charts/commit/9aba5b1e96196823ec9465fb2b7c29aa95e4f1b9))

## [0.4.2](https://github.com/Codium-ai/helm-charts/compare/module@v0.4.1...module@v0.4.2) (2025-04-03)


### Bug Fixes

* allow mounting of service accounts created outside helm release ([#21](https://github.com/Codium-ai/helm-charts/issues/21)) ([9b33854](https://github.com/Codium-ai/helm-charts/commit/9b33854658a8f0a6b73fb1612e9c34f3eb74497a))

## [0.4.1](https://github.com/Codium-ai/helm-charts/compare/module@v0.4.0...module@v0.4.1) (2025-04-02)


### Bug Fixes

* allow overriding of CONFIG.APP_NAME in main configmap ([#19](https://github.com/Codium-ai/helm-charts/issues/19)) ([dca39ad](https://github.com/Codium-ai/helm-charts/commit/dca39ad8becfc209d1b2fa410f277d167f74d63a))

## [0.4.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.3.4...module@v0.4.0) (2025-03-18)


### Features

* add topologyspreadconstraints ([fc31bed](https://github.com/Codium-ai/helm-charts/commit/fc31bedc496756673335d9b7641f97b6e2124a1d))
* add topologyspreadconstraints ([29ecfb9](https://github.com/Codium-ai/helm-charts/commit/29ecfb9d5ea80715768fb4e8d3ad7dfffb7baa14))

## [0.3.4](https://github.com/Codium-ai/helm-charts/compare/module@v0.3.3...module@v0.3.4) (2025-03-12)


### Bug Fixes

* add hooks to secrets and configmaps ([#15](https://github.com/Codium-ai/helm-charts/issues/15)) ([0406c26](https://github.com/Codium-ai/helm-charts/commit/0406c26fd86676eb9a9e2398b23eef83438719e8))

## [0.3.3](https://github.com/Codium-ai/helm-charts/compare/module@v0.3.2...module@v0.3.3) (2025-03-10)


### Bug Fixes

* add volumes support for jobs and cronjobs ([43b73e5](https://github.com/Codium-ai/helm-charts/commit/43b73e5687a092e35efa4f60d231e22accca5543))

## [0.3.2](https://github.com/Codium-ai/helm-charts/compare/module@v0.3.1...module@v0.3.2) (2025-03-04)


### Bug Fixes

* headless service support ([48e0526](https://github.com/Codium-ai/helm-charts/commit/48e0526a5167a9d5d6a7a4fb76af7a6d21727d90))

## [0.3.1](https://github.com/Codium-ai/helm-charts/compare/module@v0.3.0...module@v0.3.1) (2025-03-03)


### Bug Fixes

* remove old cronjob values from default values ([d49503d](https://github.com/Codium-ai/helm-charts/commit/d49503de3c1909d3498dd1d92c1691c70c330035))

## [0.3.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.2.2...module@v0.3.0) (2025-03-03)


### Features

* multiple cronjobs support ([a1e7f90](https://github.com/Codium-ai/helm-charts/commit/a1e7f909c4802019ba06430f52777860ef99f2b8))

## [0.2.2](https://github.com/Codium-ai/helm-charts/compare/module@v0.2.1...module@v0.2.2) (2025-02-23)


### Bug Fixes

* set default value for podTerminationGracePeriodSeconds ([4b82ad5](https://github.com/Codium-ai/helm-charts/commit/4b82ad5ff498c8dc806b9d7033f356724674089d))

## [0.2.1](https://github.com/Codium-ai/helm-charts/compare/module@v0.2.0...module@v0.2.1) (2025-02-23)


### Bug Fixes

* quote command and args ([72ae67a](https://github.com/Codium-ai/helm-charts/commit/72ae67a7101804decdc99845d31d31412030ce28))

## [0.2.0](https://github.com/Codium-ai/helm-charts/compare/module@v0.1.8...module@v0.2.0) (2025-02-20)


### Features

* add support of hostAliases in podSpec ([51af1ab](https://github.com/Codium-ai/helm-charts/commit/51af1ab2042df9a59ca85512726c4e223776a5f8))

## [0.1.8](https://github.com/Codium-ai/helm-charts/compare/module@v0.1.7...module@v0.1.8) (2025-02-20)


### Bug Fixes

* add support of additional labels for podMonitors ([8c3d476](https://github.com/Codium-ai/helm-charts/commit/8c3d476df38525314473ed2870f8b24c4b1f6fdf))

## [0.1.7](https://github.com/Codium-ai/helm-charts/compare/module-v0.1.6...module@v0.1.7) (2025-02-20)


### Bug Fixes

* service account automount is optional ([438c1ab](https://github.com/Codium-ai/helm-charts/commit/438c1ab2df67527a77cb0bdbb6369f253226ec1e))
