# tiktoken o200k_base cache bundle

This bundle was generated with `tiktoken==0.12.0` by setting `TIKTOKEN_CACHE_DIR` and loading `o200k_base`.

## Verification

```text
tiktoken version: 0.12.0
encoding: o200k_base
sample input: 'hello world'
sample output: [24912, 2375]
blob url: https://openaipublic.blob.core.windows.net/encodings/o200k_base.tiktoken
cache key: fb374d419588a4632f3f557e76b4b70aebbca790
sha256: 446a9538cb6c348e3516120d7c08b09f57c36495e2acfffe59a5bf8b0cfb1a2d
bytes: 3613922
```

## How to use this cache offline

1. Extract the ZIP.
2. Copy the file under `my-tiktoken-cache/fb374d419588a4632f3f557e76b4b70aebbca790` into your desired cache directory.
3. Set the cache directory before loading tiktoken:

```python
import os
import tiktoken

os.environ["TIKTOKEN_CACHE_DIR"] = "/path/to/my-tiktoken-cache"
enc = tiktoken.get_encoding("o200k_base")
print(enc.encode("hello world"))
```

Expected output:

```text
[24912, 2375]
```

The human-readable copy `o200k_base.tiktoken` is included for convenience, but tiktoken expects the cached file to be named exactly:

```text
fb374d419588a4632f3f557e76b4b70aebbca790
```
