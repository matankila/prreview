# tiktoken cl100k_base cache bundle

Validated with `tiktoken==0.12.0`.

The tiktoken cache file name is the SHA-1 of the blob URL:

```text
9b5ad71b2ce5302211f9c61530b329a4922fc6a4
```

The cache file in this bundle is:

```text
my-tiktoken-cache/9b5ad71b2ce5302211f9c61530b329a4922fc6a4
```

The same blob is also included with the friendly name:

```text
cl100k_base.tiktoken
```

## Validation

Blob URL:

```text
https://openaipublic.blob.core.windows.net/encodings/cl100k_base.tiktoken
```

SHA-256:

```text
223921b76ee99bde995b7ff738513eef100fb51d18c93597a113bcffe865b2a7
```

Expected SHA-256 from tiktoken v0.12.0 source:

```text
223921b76ee99bde995b7ff738513eef100fb51d18c93597a113bcffe865b2a7
```

User code output:

```text
[15339, 1917]
```

## Usage

Extract this zip, then set:

```python
import os
import tiktoken

os.environ["TIKTOKEN_CACHE_DIR"] = "/path/to/extracted/my-tiktoken-cache"

enc = tiktoken.get_encoding("cl100k_base")
print(enc.encode("hello world"))
```

Expected output:

```text
[15339, 1917]
```
